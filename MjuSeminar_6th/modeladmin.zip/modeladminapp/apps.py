from django.apps import AppConfig


class ModeladminappConfig(AppConfig):
    name = 'modeladminapp'
