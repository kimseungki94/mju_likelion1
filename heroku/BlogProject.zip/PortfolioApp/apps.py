from django.apps import AppConfig


class PortfolioappConfig(AppConfig):
    name = 'PortfolioApp'
