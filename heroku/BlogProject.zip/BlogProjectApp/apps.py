from django.apps import AppConfig


class BlogprojectappConfig(AppConfig):
    name = 'BlogProjectApp'
